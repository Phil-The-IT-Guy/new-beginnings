import React from 'react';
export default function App(){return <h1>Philip Ruffin Jr. Portfolio</h1>;}